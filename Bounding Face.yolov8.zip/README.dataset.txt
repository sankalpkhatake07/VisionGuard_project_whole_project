# Bounding Face > bounding-face
https://universe.roboflow.com/abhinav-dhakpade/bounding-face

Provided by a Roboflow user
License: CC BY 4.0

